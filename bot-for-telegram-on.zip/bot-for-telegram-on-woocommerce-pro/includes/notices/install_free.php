<div class="notice notice-warning">
    <p>
        <?php esc_html_e('Please install Bot for Telegram on WooCommerce', 'bot-for-telegram-on-woocommerce-pro'); ?>
        <a href="https://wordpress.org/plugins/bot-for-telegram-on-woocommerce/" class="button button-primary" style="margin-left: 10px;"><?php esc_html_e('Free Download', 'bot-for-telegram-on-woocommerce-pro'); ?></a>
    </p>
</div>