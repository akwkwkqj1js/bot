<?php

if (is_admin()) {
    require_once BFTOW_PRO_DIR . '/includes/alerts/db/db.php';
    require_once BFTOW_PRO_DIR . '/includes/alerts/admin/admin.php';
}
